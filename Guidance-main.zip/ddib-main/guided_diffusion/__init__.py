"""
Codebase for "Dual Diffusion Implicit Bridges for Image-to-Image Translation".
"""
